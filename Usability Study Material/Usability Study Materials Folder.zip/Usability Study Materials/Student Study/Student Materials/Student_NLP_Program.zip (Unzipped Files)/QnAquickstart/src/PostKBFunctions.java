import java.io.IOException;
import java.time.*;


public class PostKBFunctions {
	// Important variables
	private int GCSScore = 15;
	private String strokeLocation = "";
	private MemoryFunctionConcept memory1 = null;
	private LocalDate percievedDate = LocalDate.now();
	private Patient currentPatient = null;
	
	public PostKBFunctions(Patient _currentPatient) {
		currentPatient = _currentPatient;
	}
	
	
	public String postKBFunctionCaller(String qAnswer, String question) throws IOException {
		if(qAnswer.equals(".getYear()")) {
			return getYear();
		}
		else if(qAnswer.equals(".getMonth()")) {
			return getMonth();
		}
		else if(qAnswer.equals(".getDate()")) {
			return getDate();
		}
		else if(qAnswer.equals(".getDayOfWeek()")) {
			return getDayOfWeek();
		}
		else if(qAnswer.equals(".getName()")) {
			return getName();
		}
		else if(qAnswer.equals(".getLocation()")) {
			return getLocation();
		}
		else if(qAnswer.equals(".getAge()")) {
			return getAge();
		}
		else if(qAnswer.equals(".getRememberInitial()")) { 								
			memory1 = new MemoryFunctionConcept(question,GCSScore,strokeLocation);
			return "Speaker 1: " + memory1.recall();
		}
		else if(qAnswer.equals(".getRememberFollowup()")) {	
			if (memory1!=null) {
				memory1.updateLocation(strokeLocation);
				memory1.updateSeverity(GCSScore);
				return "Speaker 1: " + memory1.recall();
			}
			return "Speaker 2: Error: Please ask initial question to test short term memory";
		}
		else if(qAnswer.equals(".getCalculation()")) {
			return CalculateFunctionConcepts.makeCalculation(question,GCSScore,strokeLocation);
		}
		else {
			return "Speaker 2: Function " + qAnswer +
				   " corresponding to your question has not been defined. Please try again.";
		}
				
	}
	
	//updates GCS score and percieved date
	public void updateGCSScore(int newGCSScore) {
		//update percieved time
		if (GCSScore != newGCSScore) {
			if(newGCSScore >= 14){
				percievedDate = LocalDate.now();
				GCSScore = newGCSScore;
			}
			else if(newGCSScore == 13) {
				percievedDate = LocalDate.now().minusDays((long)(Math.random()*30)+1);
				GCSScore = newGCSScore;
			}
			else if(newGCSScore >= 10) {
				percievedDate = LocalDate.now().minusDays((long)(Math.random()*2000)+1);
				GCSScore = newGCSScore;
			}
			else {
				percievedDate = LocalDate.now().minusDays((long)(Math.random()*3000)+1000);
				GCSScore = newGCSScore;
			}
			//change perciveved time and date accordingly
		}
	}
	
	
	public void updateStrokeLocation(String newStrokeLocation) {
		strokeLocation = newStrokeLocation;
	}

	private String getYear() {
		return "Speaker 1: It is " + percievedDate.getYear() + ".";
	}
	
	private String getMonth() {
		return "Speaker 1: It is " + percievedDate.getMonth().name().toLowerCase() + ".";
	}
	
	private String getDate() {
		return "Speaker 1: It is " + percievedDate.getMonth().name().toLowerCase() + " " +
				percievedDate.getDayOfMonth() + ".";
	}
	
	private String getDayOfWeek() {
		return "Speaker 1: It's " + percievedDate.getDayOfWeek().name().toLowerCase() + ".";
	}
	
	private String getName() {
		if(GCSScore >=11) {
			return "Speaker 2: Patient gave correct name.";
		}
		else {
			return "Speaker 1: Uhh I don't know.";
		}
	}

	private String getLocation() {
		if(GCSScore >=13) {
			return "I'm at a hospital.";
		}
		else {
			return "Speaker 1: Uhh I'm not sure where I am.";
		}
	}
	
	private String getAge() {
		if(GCSScore >=11) {
			return "I'm " + currentPatient.getAge() + " years old." ;
		}
		else {
			return "Speaker 1: Uhh I'm not sure how old I am.";
		}
	}
	
}

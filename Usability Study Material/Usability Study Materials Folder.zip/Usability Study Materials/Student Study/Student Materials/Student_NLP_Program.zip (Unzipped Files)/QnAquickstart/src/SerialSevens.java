/*
 * BIOE Team Design
 * Year: 2020-2021
 * 
 * This class contains a method that count down from a requested number sevens an base
 * its response on the GCS severity and location of stroke in brain.
 * 
 * The class is written under the assumption there the patient has information
 * on GCS and location of stroke in brain. Note the locations evaluated so far
 * are parietal lobe, occipital lobe, and cerebellum.
 * 
 * Clients are able to use the following list of methods to acquire data:
 * 
   - countBySevens(int gcs, String question)
   - getTriggerWords()

 */

import java.util.*;
import com.github.dhiraj072.randomwordgenerator.RandomWordGenerator; // DELETE if errors arise

public class SerialSevens {
	private static List<String> relevantStrokeLocations = new ArrayList<String>(Arrays.asList("Right Parietal",
																							  "Left Parietal"));
	private static List<String> triggerWords = new ArrayList<String>(Arrays.asList("from", "count" , "by 7"));
	private static List<String> randomWords = new ArrayList<String>(Arrays.asList("Bacon", "Blue" , "Whale",
																				  "Couch", "Beluga", ""));
	private static int countBy = 7;

	public static String countBySevens(int gcs, String question, String location) {
		int startCount = startNum(question) - countBy;
		String response = "";
		int numCount = startCount / countBy;
		boolean affectSerialSevens = false;
				
		for (int i = 0; i < relevantStrokeLocations.size() && !affectSerialSevens; i++) {
			if (location.equals(relevantStrokeLocations.get(i))) {
				affectSerialSevens = true;
			}
		}
		
		if (affectSerialSevens) {
			if (gcs == 15 || gcs == 14) {
				for (int i = startCount; i >= (startCount - numCount * countBy); i = i - countBy) {
					response = response + Integer.toString(i) + ". ";
				}
				return response;
			} else if (gcs >= 10 && gcs <= 13) {
				String[] pauses = {"Um. ", "Uh. ", "Hmmm. "};
				Random rand = new Random();
				int level = gcs - 10; // uses 4 levels of severity
				int range = 20 - level * 4 ; // TODO need to find data on probability
				int desiredRange = 2;    
				int[] numCountProb = {25, 50, 75, 100};
				numCount = (int) (numCount * (numCountProb[level] - rand.nextInt(25)) / 100.0);

				for (int i = startCount; i >= (startCount - numCount * countBy); i = i - countBy) {
					i = i + (int) rand.nextGaussian() * 1 * level;
					if (rand.nextInt(range) <= desiredRange) {
						String chosenPause = pauses[rand.nextInt(pauses.length)];
						response = response + chosenPause + Integer.toString(i) + ". ";
					} else {
						response = response + Integer.toString(i) + ". ";
					}
				}
				return response;
			} else if (gcs == 9) {
				Random rand = new Random();
				double num = rand.nextDouble();
				if (num < 0.33) {
					return (RandomWordGenerator.getRandomWord() + " " +
							RandomWordGenerator.getRandomWord());

				} else if (num < 0.66) {
					return Integer.toString(rand.nextInt(1000));
				} else {
					return (RandomWordGenerator.getRandomWord() + " " +
							Integer.toString(rand.nextInt(1000)));
				}
			} else {
				return  "...huhh...urgh...uh";
			}
		} else {
			for (int i = startCount; i >= (startCount - numCount * countBy); i = i - countBy) {
				response = response + Integer.toString(i) + ". ";
			}
			return response;
		}	
	}

	public static List<String> getTriggerWords(){
		return triggerWords;
	}

	// assumes given question is a request to count
	// assumes all counting question uses from
	private static int startNum(String question) {
		String substringQuestion = question.substring(question.indexOf("from"));
		String[] wordArray = substringQuestion.split("\\s+");
		String word = wordArray[1];
		word = word.replaceAll("\\p{Punct}", "");
		return Integer.parseInt(word);
	}

}

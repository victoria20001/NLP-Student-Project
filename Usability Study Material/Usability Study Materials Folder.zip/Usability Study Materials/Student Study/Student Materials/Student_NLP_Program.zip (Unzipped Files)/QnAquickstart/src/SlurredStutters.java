// Favour Orji
// CREST AMM
// Stuttering 

/*
   This program will attempt to replicate stuttering that is seen in TBI related injuries
   Notes: 
      - Stuttering code modified based on GGlasgow Stroke Scale:
         - Broca's Aphasia:Injury to the frontal regions of the left hemisphere impacts 
           how words are strung together to form complete sentences. 
           This can lead to Broca’s Aphasia, which is characterized by:
              - Difficulty forming complete sentences.
              - Leaving out words like “is” or “the.”
              - Saying something that doesn’t resemble a sentence.
              - Trouble understanding sentences.  
         - Wernicke's Aphasia: 
         - Global Aphasia: A stroke that affects an extensive portion of your 
           front and back regions of the left hemisphere may result in Global Aphasia. 
           You may have difficulty:
              - Understanding words and sentences.
              - Forming words and sentences.

          Overall scale:
            - Oriented, confused, inappropirate words, incomprehendible, and no response

Note the locations evaluated so far
 * are parietal lobe, occipital lobe, and cerebellum.

 */
import java.util.*;

public class SlurredStutters {
	private static List<String> relevantStrokeLocations = new ArrayList<String>(Arrays.asList("Right Parietal",
																							  "Left Parietal",
																							  "Cerebellum",
																					       	  "Occipital"));

	public static String slurredResponse(String response, int severity, String location){
		boolean affectResponse = false;
		
		for (int i = 0; i < relevantStrokeLocations.size() && !affectResponse; i++) {
			if (location.equals(relevantStrokeLocations.get(i))) {
				affectResponse = true;
			}
		}

		if (affectResponse) {
			if (severity == 13 ||severity  == 12) {
				return slurredL1(response);
			} else if (severity == 11) {
				return slurredL2(response);
			} else if (severity == 10){
				return slurredL3(response);
			} else if (severity == 9){
				return slurredL4(response);
			} else if (severity == 8){
				return slurredL5(response);      
			} else if (severity == 7){
				return slurredL6(response);
			} else {
				return response;
			}
		} else {
			return response;
		}	
	}

	/* This methods below needs to be private (the client doesn't need to use them) */

	public static String slurredL1(String qnAResponse){
		String L1 = qnAResponse;
		String replaceL1 = L1.replace("a", "aaaaa");
		return replaceL1;
	}  

	// This prints to the console. We need it to store as a String.
	public static String slurredL2(String qnAResponse){
		String line = qnAResponse;
		String[] arr = line.split("\\s+");
		for (int i = 0; i < arr.length; i++){
			System.out.print(arr[i] + " ");

			if ((i+1) % 3 == 0) {
				System.out.print(arr[i] + " ");

				System.out.print(arr[i] + " ");
			}
		}
		return line;
	}


	public static String slurredL3(String qnAResponse){
		String L2 =  qnAResponse;
		String replaceL2 = L2.replaceAll("is", "").replaceAll("the", "");

		return replaceL2;
	}

	// look at while loop and qnaResponse() --> this is not an exisiting method
	// though thre is ne below but returns a String not a boolean
	public static String slurredL4(String response) {
		Scanner sc = new Scanner(response);
		int skip = 5;
		int count = 0;
		int repeat = 4;
		String s = response; 
		while(sc.hasNext()){
			String word = sc.next();
			if (count % skip == 0){
				for (int i = 0; i < repeat; i++){
					s += word.charAt(0) + "uh";
				} 
			} 
			s += word + " ";
			count++;
		}
		return s;
	}

	// this also uses a while qnaResponse()
	public static String slurredL5(String response){
		Scanner sc = new Scanner(response);
		int skip = 2;
		int count = -1;
		String s = ""; 
		while(sc.hasNext()) {
			String word = sc.next();
			if (count % skip != 0){
				s += word + " ";
			} 
			count++;
		}
		return s;
	}


	public static String slurredL6(String response) {
		Scanner sc = new Scanner(response);
		int skip = 3;
		int count = -1;
		String s = ""; 
		while(sc.hasNext()){
			String word = sc.next();
			if (count % skip != 0){
				s += word + " ";
			} 
			count++;
		}
		return s;
	}
}

/* 
 * BIOE Team Design
 * Year: 2020-2021
 * 
 * This is the Natural Language Processing program that will act as either
 * a given patient or a nurse in the room and will provide an appropriate
 * response based on the user/client's verbally asked question
 * This is assumed to be used in conjunction with a Biogears engine.
 * 
 */

import java.io.*;
import java.lang.Object.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.net.*;

import com.microsoft.cognitiveservices.speech.AudioDataStream;
import com.microsoft.cognitiveservices.speech.SpeechConfig;
import com.microsoft.cognitiveservices.speech.SpeechSynthesizer;
import com.microsoft.cognitiveservices.speech.SpeechSynthesisOutputFormat;
import com.microsoft.cognitiveservices.speech.SpeechSynthesisResult;
import com.microsoft.cognitiveservices.speech.audio.AudioConfig;

import com.microsoft.cognitiveservices.speech.*;
import com.microsoft.cognitiveservices.speech.audio.AudioConfig;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.Semaphore;
import java.time.*;


public class MainClient {
	//Subscription information
	private static String speechToTextToSpeech_subscription_ID = "432e712364ac4896a5155cd56681b262";
	private static String speechToTextToSpeech_subscription_region= "westus2";
	private static String qna_authoring_key = "6d7e89dd1ee74e2a8c067ecd3d0f928a";
	private static String qna_authoring_endpoint = "https://qandamaker2.cognitiveservices.azure.com";
	private static String qna_runtime_endpoint = "https://qandamaker2.azurewebsites.net";

	//Output filePath
	private static String wavOutputPath = "";

	private static Semaphore stopTranslationWithFileSemaphore;
	private static String qna;

	// Initializes for information from Biogears to create patient for assigning speech characteristics and
	// its corresponding Microsoft Azure QnA knowledge base.
	// This main method will continuously listen for a voice through microphone. After a period of silence
	// the speech will convert to text. After a query or special functions for appropriate
	// response, outputs a wave file. Then resumes to listen for voice/speech.
	public static void main(String[] args) throws InterruptedException, ExecutionException,
	FileNotFoundException, IOException {
		SpeechConfig speechConfig = SpeechConfig.fromSubscription(speechToTextToSpeech_subscription_ID,
				speechToTextToSpeech_subscription_region);
		AudioConfig audioConfig = AudioConfig.fromDefaultMicrophoneInput();
		SpeechRecognizer recognizer = new SpeechRecognizer(speechConfig, audioConfig);  
		SpeechSynthesizer synthesizer = new SpeechSynthesizer(speechConfig, null);
		MakeSound soundPlayer = new MakeSound();

		// First initialize the semaphore.
		stopTranslationWithFileSemaphore = new Semaphore(0);

		// Makes a KBMakerClient instance so the .query_kb method can be used
		KBMakerClient quickstart = new KBMakerClient(qna_authoring_key,qna_authoring_endpoint,qna_runtime_endpoint);

		// Makes patient with correct voice characteristics and knowledge base
		//Patient currentPatient = new Patient();
		Patient currentPatient = new Patient(quickstart);
		PostKBFunctions postKBFunctions = new PostKBFunctions(currentPatient);
		System.out.println("Welcome to the Patient QnA simulator, "
				+ "a natural language processing program designed to simulate provider-patient interaction. \n\n"
				+ "For more detailed information on the program, " 
				+ "please read the READ_ME in the QnAquickstart directory.\n"
				+ "If you wish to provide additional feedback, please visit the following url: "
				+ "https://forms.gle/avbZwgHAk2uR1nJT9\n\n"
				+ "To get started, please enter the folder path (ex. /Users/[username]/Desktop/) " 
				+ "where generated wav files of answers will\n"
				+ "be stored, and press enter:");
				
		Scanner scan = new Scanner(System.in);
		wavOutputPath = scan.nextLine();
		boolean folderPathExists = false;
		if(!wavOutputPath.contains("/")) {
			folderPathExists = false;
		}
		else {
			folderPathExists = new File(wavOutputPath).exists();	
		}
		
		while(!folderPathExists) {
			System.out.println("Path does not exist. Please try again");
			Scanner scan2 = new Scanner(System.in);
			wavOutputPath = scan2.nextLine();
			if(!wavOutputPath.contains("/")) {
				folderPathExists = false;
			}
			else {
				folderPathExists = new File(wavOutputPath).exists();	
			}
		}
		
		System.out.println("\nNow please ask questions into your program's microphone:");
		
		int questionNum = 1;
		
		// Prints words of an ongoing verbal statement from microphone
		recognizer.recognizing.addEventListener((s, e) -> {
			// System.out.println("RECOGNIZING: Text=" + e.getResult().getText());
		});

		// Acquires final String of verbal statement. A response to verbal statement is
		// made and output as a wav file.
		recognizer.recognized.addEventListener((s, e) -> {

			if (e.getResult().getReason() == ResultReason.RecognizedSpeech) {
				System.out.println("RECOGNIZED: Text=" + e.getResult().getText());
				currentPatient.updatePatient();
				String response = "";
				String speaker = "";
				String style = ""; 
				String speechSpeed = "";
				
				if (currentPatient.getGlasgowComaScale() < 7) {
					response = "...";
					speaker = "SPEAKER 1";
				} else {
					String kb_id = currentPatient.getKbId(); // identify correct knowledge base
					
					//processing numbers out of question so that calculate function can be called appropriately
					String recognizedSpeech = e.getResult().getText();
					String question1 = recognizedSpeech.replace("0","x");
					question1 = question1.replaceAll("1", "x");
					question1 = question1.replaceAll("2", "x");
					question1 = question1.replaceAll("3", "x");
					question1 = question1.replaceAll("4", "x");
					question1 = question1.replaceAll("5", "x");
					question1 = question1.replaceAll("6", "x");
					question1 = question1.replaceAll("7", "x");
					question1 = question1.replaceAll("8", "x");
					question1 = question1.replaceAll("9", "x");

					// Check if acquired verbal statement matches question in knowledge base if not
					// matched in knowledge base
					response = quickstart.query_kb(kb_id, question1); // query the knowledge base
	
					if(response.startsWith(".get")) {
						try {
							postKBFunctions.updateGCSScore(currentPatient.getGlasgowComaScale());
							postKBFunctions.updateStrokeLocation(currentPatient.getStrokeLocation());
							response = postKBFunctions.postKBFunctionCaller(response, recognizedSpeech);
						} catch (IOException e1) {
							// TODO Auto-generated catch block
							response = "Speaker 2: Function " + response + 
									   " corresponding to your question has not been defined. Please try again.";
							e1.printStackTrace();
						}
					}

					if (response.contains(":")) {
						String columns[] = response.split(":");
						speaker = columns[0].toUpperCase().replaceAll("\\s","");
						response = columns[1];
					} else {
						speaker = "SPEAKER 1";
					}				                  				
				}
				
				// Assign voice for Speaker 1 (Patient) or Speaker 2 (Nurse/Alternative Person)
				if (speaker.equals("SPEAKER 1") || speaker.equals("SPEAKER1")) {
					speaker = currentPatient.getVoice();
					style = currentPatient.voiceStyle;
					speechSpeed = currentPatient.getProsodyRate();

					// Slurrs speech if applicable
					response = SlurredStutters.slurredResponse(response, currentPatient.getGlasgowComaScale(),
															   currentPatient.getStrokeLocation());
				} else if (speaker.equals("SPEAKER 2") || speaker.equals("SPEAKER2")) {
					speaker = "en-US-AriaNeural";
					style = "customerservice";
					speechSpeed = "0.9";
				} else {
					// Used for debugging.
					System.out.println("Invalid QnA Output. Must match format 'Speaker #:TEXT'. # = 1 or 2" );
				}
				
				// Text to Speak
				String textToSpeak = "<speak version=\"1.0\" xmlns=\"https://www.w3.org/2001/10/synthesis\""
						+ " xmlns:mstts=\"https://www.w3.org/2001/mstts\" xml:lang=\"en-US\">"
						+ " <voice name=\"" + speaker + "\">"
						+ " <mstts:express-as style=\"" + style + "\">"
						+ " <prosody rate=\"" + speechSpeed + "\">"
						+ " " + response
						+ " </prosody>"
						+ " </mstts:express-as>"
						+ "  </voice>"
						+ "</speak>";
				SpeechSynthesisResult result = synthesizer.SpeakSsml(textToSpeak);
				System.out.println(textToSpeak); // DELETE
				AudioDataStream stream = AudioDataStream.fromResult(result);
				LocalTime currentTime = LocalTime.now();
				String time = "" + currentTime.getMinute() + "-" + currentTime.getSecond();
				String waveFilePath = wavOutputPath + "answer" + time + ".wav";
				stream.saveToWavFile(waveFilePath);
				// TODO Integrate to Speaker to Biogears	
				soundPlayer.playSound(waveFilePath); // Temporary Speakers from Computer used here
				System.out.println(response); // DELETE
				
				
			}
			else if (e.getResult().getReason() == ResultReason.NoMatch) {
				System.out.println("NOMATCH: Speech could not be recognized.");
			}
		});

		recognizer.canceled.addEventListener((s, e) -> {
			System.out.println("CANCELED: Reason=" + e.getReason());

			if (e.getReason() == CancellationReason.Error) {
				System.out.println("CANCELED: ErrorCode=" + e.getErrorCode());
				System.out.println("CANCELED: ErrorDetails=" + e.getErrorDetails());
				System.out.println("CANCELED: Did you update the subscription info?");
			}

			stopTranslationWithFileSemaphore.release();
		});

		recognizer.sessionStopped.addEventListener((s, e) -> {
			System.out.println("\n    Session stopped event.");
			stopTranslationWithFileSemaphore.release();
		});

		// Starts continuous recognition. Uses StopContinuousRecognitionAsync() to stop recognition.
		recognizer.startContinuousRecognitionAsync().get();

		// Waits for completion.
		stopTranslationWithFileSemaphore.acquire();

		// Stops recognition.
		recognizer.stopContinuousRecognitionAsync().get();

	}    
}
import java.util.concurrent.ExecutionException;
import java.util.*;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;  
import org.apache.poi.xssf.usermodel.XSSFSheet;  
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import com.microsoft.azure.cognitiveservices.knowledge.qnamaker.*;
//These are to resolve typing
import com.microsoft.azure.cognitiveservices.knowledge.qnamaker.models.*;
import com.microsoft.azure.cognitiveservices.knowledge.qnamaker.models.QnADTO;
import com.microsoft.azure.cognitiveservices.knowledge.qnamaker.models.CreateKbDTO;
import com.microsoft.azure.cognitiveservices.knowledge.qnamaker.QnAMakerClient;

import java.io.*;
import java.lang.Object.*;
import java.time.format.DateTimeFormatter;  
import java.time.LocalDateTime; 
import java.net.*;  
import com.fasterxml.jackson.annotation.JsonProperty;

public class KnowledgeBaseMaker {
	
	// Trevor's #2: Currently on Basic Tier (as created)
	public static String authoring_key = "6d7e89dd1ee74e2a8c067ecd3d0f928a";
	public static String authoring_endpoint = "https://qandamaker2.cognitiveservices.azure.com";
	public static String runtime_endpoint = "https://qandamaker2.azurewebsites.net";
	
	QnAMakerClient authoring_client = QnAMakerManager.authenticate(authoring_key).withEndpoint(authoring_endpoint);
	Knowledgebases kb_client = authoring_client.knowledgebases();
	Operations ops_client = authoring_client.operations();
	EndpointKeys keys_client = authoring_client.endpointKeys();
	// /Users/trevorjohnston/Desktop/AMMAudioFiles/Test5.xlsx
	
	public static void main(String[] args) throws Exception {  
		KnowledgeBaseMaker currentInstance = new KnowledgeBaseMaker();
		boolean cont = true;
		Scanner scan = new Scanner(System.in);
		System.out.println("Welcome to the Knowledge Base Manager. The following knowledge bases exist:\n");
		String KBIDList = currentInstance.listKnowledgebases(); //list kbs
		//--------------------Entering Program---------------------------//
		while(cont) {		
			System.out.println("\nEnter the number of the operation you would like to perform, or 0 to quit:");		
			System.out.println("1. Create .xlsx file summary of an existing knowledge base.\n"
							+ "2. Update an existing knowledge base.\n"
							+ "3. Create new knowledge base.\n"
							+ "4. Delete a knowledge base.");
			int selection1 = -1;
			boolean continue1 = true;
			
			while(continue1) {
				if(!scan.hasNextInt()){
					System.out.println("\nPlease enter a valid integer selection:");
					scan.next();
				}
				else {
					selection1 = scan.nextInt();
					if(selection1<0 || selection1>4) {
						System.out.println("\nPlease enter a valid integer selection:");
					}
					else {
						continue1 = false;
					}
				}
			}
			if(selection1 == 0) {
				break;
			} 
			
			//------------------Creating summary .xlsx output-----------------// DONE
			else if(selection1 == 1) {
				System.out.println("\nEnter the ID of the knowledge base to summarize:");
				Scanner scan1 = new Scanner(System.in);
				String kBSelection = scan1.nextLine();		
				while (KBIDList.indexOf(" " + kBSelection + " ")<0) {
					System.out.println("Invalid knowledge base ID, please try again:");
					Scanner scan2 = new Scanner(System.in);
					kBSelection = scan2.nextLine();
				}
				currentInstance.download_kb(kBSelection);
			}
			
			//--------Export KB as editable .xlms, asks to clear kb, reupload edited file -----// DONE
			else if(selection1 == 2) {
				System.out.println("\nEnter the ID of the knowledge base to edit:");
				Scanner scan8 = new Scanner(System.in);
				String kBSelection = scan8.nextLine();
				while (KBIDList.indexOf(kBSelection)<0) {
					System.out.println("Invalid knowledge base ID: please try again:");
					Scanner scan12 = new Scanner(System.in);
					kBSelection = scan12.nextLine();
				}
				currentInstance.updateKBWithLocalFile(kBSelection);
			}
			
			
			//---------------Code for adding a new database-------------//
			else if(selection1 == 3) {
				System.out.println("\nEnter the name of the knowledge base that you wish to upload:");
				Scanner scan4 = new Scanner(System.in);
				String KBName = scan4.nextLine();
				
				KBIDList += currentInstance.createKB(KBName) + " ";
			}
			else if(selection1 == 4) {
				System.out.println("\nEnter the ID of the knowledge base to create .xlsx sumary of and then delete:");
				Scanner scan20 = new Scanner(System.in);
				String kBSelection = scan20.nextLine();
				while (KBIDList.indexOf(kBSelection)<0) {
					System.out.println("Invalid knowledge base ID: please try again:");
					Scanner scan21 = new Scanner(System.in);
					kBSelection = scan21.nextLine();
				}
				currentInstance.download_kb(kBSelection);
				currentInstance.delete_kb(kBSelection);
			}
		}  
	}
	
	//------Summarizes the Question and Answer pairs in an xlsx document---//
	public void download_kb(String kb_id) throws FileNotFoundException, IOException {
		System.out.println("Downloading KB...");
		var kb_data = kb_client.download(kb_id, EnvironmentType.PROD);

		System.out.println("Downloaded KB.\n");
		//System.out.println(kb_data.qnaDocuments().toString());
		System.out.println("\nEnter the file path of the new file for output (.xlsx): ");
		Scanner scan4 = new Scanner(System.in);
		String outputFilePath = scan4.nextLine();
		boolean folderPathExists = false;
		if(!outputFilePath.contains("/")) {
			folderPathExists = false;
		}
		else {
			folderPathExists = new File(outputFilePath.substring(0,outputFilePath.lastIndexOf("/"))).exists();
	
		}
		
		while(outputFilePath.length()<6 || !folderPathExists || !outputFilePath.contains(".xlsx")) {
			if(!folderPathExists) {
				System.out.println("Path does not exist. Please try again");
			}
			else if(!outputFilePath.contains(".xlsx")) {
				System.out.println("File is not in .xlsx format. Please try again");
			}
			Scanner scan3 = new Scanner(System.in);
			outputFilePath = scan3.nextLine();
			if(!outputFilePath.contains("/")) {
				folderPathExists = false;
			}
			else {
				folderPathExists = new File(outputFilePath.substring(0,outputFilePath.lastIndexOf("/"))).exists();
		
			}
		}
		XSSFWorkbook QnAList_wb = new XSSFWorkbook();
		XSSFSheet QnAList_sheet = QnAList_wb.createSheet(kb_id);
		int rowCount = 0;
		Row headerRow = QnAList_sheet.createRow(0);
		Cell qHeaderCell = headerRow.createCell(0);
		qHeaderCell.setCellValue("Questions");
		Cell aHeaderCell = headerRow.createCell(1);
		aHeaderCell.setCellValue("Answers");
		
		for(QnADTO QnAObj: kb_data.qnaDocuments()) {
			for(String question: QnAObj.questions()) {
				Row row = QnAList_sheet.createRow(++rowCount);
				Cell qCell = row.createCell(0);
				qCell.setCellValue(question);
				Cell aCell = row.createCell(1);
				aCell.setCellValue(QnAObj.answer());	
			}
		}
		File outPutFile = new File(outputFilePath);
		FileOutputStream outputStream = new FileOutputStream(outputFilePath);
		QnAList_wb.write(outputStream);
		QnAList_wb.close();
	}

	//-------updates a given KB by outputting an editable xlsx file----//
	public void updateKBWithLocalFile(String kBSelection) throws Exception {
		
		//--Download KB
		System.out.println("Downloading KB...");
		var kb_data = kb_client.download(kBSelection, EnvironmentType.PROD);
		System.out.println("Downloaded KB.\n");
		
		//--Write .xlsx file
		System.out.println("\nEnter the file path of the .xlsx file to be created, editted, and reuploaded:");
		Scanner scan14 = new Scanner(System.in);
		String filePath = scan14.nextLine();
		
		// /Users/trevorjohnston/Desktop/AMMAudioFiles/OutputEditable.xlsx
		
		String outputFolderPath = filePath.substring(0,filePath.lastIndexOf("/"));
		boolean folderPathExists = new File(outputFolderPath).exists();
		while(!folderPathExists || !filePath.contains(".xlsx")) {
			if(!folderPathExists) {
				System.out.println("Path does not exist. Please try again");
			}
			else if(!filePath.contains(".xlsx")) {
				System.out.println("File is not in .xlsx format. Please try again");
			}
			Scanner scan13 = new Scanner(System.in);
			filePath = scan13.nextLine();
			folderPathExists = new File(filePath.substring(0,filePath.lastIndexOf("/"))).exists();
		}
		
		XSSFWorkbook QnAList_wb = new XSSFWorkbook();
		XSSFSheet QnAList_sheet = QnAList_wb.createSheet(kBSelection);
		int rowCount = 0;
		Row headerRow = QnAList_sheet.createRow(0);
		Cell qHeaderCell = headerRow.createCell(0);
		qHeaderCell.setCellValue("Questions");
		Cell aHeaderCell = headerRow.createCell(1);
		aHeaderCell.setCellValue("Answers");
		
		for(QnADTO QnAObj: kb_data.qnaDocuments()) {
			for(String question: QnAObj.questions()) {
				Row row = QnAList_sheet.createRow(++rowCount);
				Cell qCell = row.createCell(0);
				qCell.setCellValue(question);
				Cell aCell = row.createCell(1);
				aCell.setCellValue(QnAObj.answer());	
			}
		}
		File outPutFile = new File(filePath);
		FileOutputStream outputStream = new FileOutputStream(filePath);
		QnAList_wb.write(outputStream);
		QnAList_wb.close();
		System.out.println("Knowledge base is now copied to "+ filePath);
		System.out.println("Edit knowledge base in the xlsx file and save when finished.");
		System.out.println("\nEnter 1 in console when finished a) to clear the knowledge base and b) to add the QnA pairs to the knowledgebase: ");
		Scanner scan11 = new Scanner(System.in);
		int deleteToken = scan11.nextInt();
		if (deleteToken !=1) {
			System.exit(0);
		}
		
		//--delete old QnA pairs
		System.out.println("\nClearing knowledgebase...");
		List<QnADTO> oldQnAList = kb_data.qnaDocuments();
		
		List<Integer> oldQnAListIds = new ArrayList<Integer>();
		for(int i = 0; i < oldQnAList.size(); i++) {
			oldQnAListIds.add((Integer)oldQnAList.get(i).id());
		}
		
		var deletion = new UpdateKbOperationDTODelete().withIds(oldQnAListIds);
	    var payload1 = new UpdateKbOperationDTO().withDelete((UpdateKbOperationDTODelete)deletion);
	    var result1 = kb_client.update(kBSelection, payload1);
	    wait_for_operation(result1);
	    System.out.println("Knowledge base cleared.");
		
		//--add new QnA pairs	
		System.out.println("\nAdding to KB...");
		File QnAList = new File(filePath);
		FileInputStream QnAListFIS = new FileInputStream(QnAList);   //obtaining bytes from the file  
		//creating Workbook instance that refers to .xlsx file  
		XSSFWorkbook QnAListWB = new XSSFWorkbook(QnAListFIS);   
		XSSFSheet QnAListSheet = QnAListWB.getSheetAt(0);     //creating a Sheet object to retrieve object  
		Iterator<Row> QnAitr = QnAListSheet.iterator();    //iterating over excel file
		QnAitr.next(); //start one down
		
		List<QnADTO> qna_list = new ArrayList<QnADTO>();
		String currentQuestion = "";
		String currentAnswer = "";
		String previousAnswer = "";
		List<String> questionList = new ArrayList<String>();
		int rowNum = 1;
		while (QnAitr.hasNext()){               
			Row row = QnAitr.next(); 
			Iterator<Cell> cellIterator = row.cellIterator();   //iterating over each column
			currentQuestion = cellIterator.next().getStringCellValue();
			currentAnswer = cellIterator.next().getStringCellValue();
			if(!currentAnswer.equals(previousAnswer)&& rowNum > 1) {
				List<String> questionListCopy = new ArrayList<String>();
				for(int i = 0; i<questionList.size(); i++) {
					questionListCopy.add(""+i);
				}
				Collections.copy(questionListCopy, questionList);
				
				var qna = new QnADTO().withAnswer(previousAnswer).withQuestions(questionListCopy);
				previousAnswer = currentAnswer;
				questionList.clear();
				qna_list.add(qna);
			}
			else if(rowNum==1) {
				previousAnswer = currentAnswer;
			}
			questionList.add(currentQuestion);
			rowNum ++;
		}
		var qna = new QnADTO().withAnswer(currentAnswer).withQuestions(questionList);
		qna_list.add(qna);
		QnAListWB.close();
		
		var addition = new UpdateKbOperationDTOAdd().withQnaList(qna_list);	
	    var payload = new UpdateKbOperationDTO().withAdd((UpdateKbOperationDTOAdd)addition);
	    var result = kb_client.update(kBSelection, payload);
	    wait_for_operation(result);
	    
	    System.out.println("Added to KB.");
		System.out.println("\nPublishing KB...");
		kb_client.publish(kBSelection);
		System.out.println("KB_ID: " + kBSelection + " re-published.\n");
	}
	
	
	public String createKB(String KBName) throws Exception {
		
		System.out.println("\nEnter the filepath of .xlsx file containing question answer pairs for the new knowledge base:\n"
				+ "(input \"format\" if you would like to review .xlsx format requirements)");
		Scanner scan15 = new Scanner(System.in);
		String filePath = scan15.nextLine();
		
		
		if(filePath.equalsIgnoreCase("format")){
			System.out.println("Row 1 must Contain \"Questions\" in column 1 and \"Answeres\" in column2"
								+ "\nQuestions with the same answers must in adjacent rows"
								+ "\nAnswers must begin with either \n\t1. \"Speaker 1:\" for audio directed to patient speaker"
								+ " \n\t2. \"Speaker 2:\" for audio directed to ambient speaker"
								+ " \n\t3. \".get\" for audio directed to function file for better answer determination");
			System.out.println("\nEnter the filepath of .xlsx file containing question answer pairs for the new knowledge base:\n");
			Scanner scan22 = new Scanner(System.in);
			filePath = scan22.nextLine();
		}
		
		
		boolean filePathExists = new File(filePath).exists();
		while(!filePathExists || !filePath.contains(".xlsx")) {
			if(!filePathExists) {
				System.out.println("Path does not exist. Please try again");
			}
			else if(!filePath.contains(".xlsx")) {
				System.out.println("File is not in .xlsx format. Please try again");
			}
			Scanner scan16 = new Scanner(System.in);
			filePath = scan16.nextLine();
			filePathExists = new File(filePath.substring(0,filePath.lastIndexOf("/"))).exists();
		}
		
		
		//--add new QnA pairs	
		System.out.println("\nCreating KB...");
		File QnAList = new File(filePath);
		FileInputStream QnAListFIS = new FileInputStream(QnAList);   //obtaining bytes from the file  
		//creating Workbook instance that refers to .xlsx file  
		XSSFWorkbook QnAListWB = new XSSFWorkbook(QnAListFIS);   
		XSSFSheet QnAListSheet = QnAListWB.getSheetAt(0);     //creating a Sheet object to retrieve object  
		Iterator<Row> QnAitr = QnAListSheet.iterator();    //iterating over excel file
		QnAitr.next(); //start one down
		
		List<QnADTO> qna_list = new ArrayList<QnADTO>();
		String currentQuestion = "";
		String currentAnswer = "";
		String previousAnswer = "";
		List<String> questionList = new ArrayList<String>();
		int rowNum = 1;
		while (QnAitr.hasNext()){               
			Row row = QnAitr.next(); 
			Iterator<Cell> cellIterator = row.cellIterator();   //iterating over each column
			currentQuestion = cellIterator.next().getStringCellValue();
			currentAnswer = cellIterator.next().getStringCellValue();
			if(!currentAnswer.equals(previousAnswer)&& rowNum > 1) {
				List<String> questionListCopy = new ArrayList<String>();
				for(int i = 0; i<questionList.size(); i++) {
					questionListCopy.add(""+i);
				}
				Collections.copy(questionListCopy, questionList);
				
				var qna = new QnADTO().withAnswer(previousAnswer).withQuestions(questionListCopy);
				previousAnswer = currentAnswer;
				questionList.clear();
				qna_list.add(qna);
			}
			else if(rowNum==1) {
				previousAnswer = currentAnswer;
			}
			questionList.add(currentQuestion);
			rowNum ++;
		}
		var qna = new QnADTO().withAnswer(currentAnswer).withQuestions(questionList);
		qna_list.add(qna);
		QnAListWB.close();
		
		var payload = new CreateKbDTO().withName(KBName).withQnaList(qna_list);
		
	    var result = kb_client.create((CreateKbDTO) payload);
	    var kb_id = wait_for_operation(result);

	    System.out.println("Created KB with ID: " + kb_id + "\nand name: "+KBName);
	    
	    System.out.println("\nPublishing KB...");
	    kb_client.publish(kb_id);
	    System.out.println("Published KB");
	    
	    return kb_id;
	    
	}
	
	public void delete_kb(String kb_id) {
		System.out.println("Deleting KB...");
		kb_client.delete(kb_id);
		System.out.println("KB deleted.\n");
	}
	
	public String listKnowledgebases() {
		KnowledgebasesDTO allKBs = kb_client.listAll();
		List<KnowledgebaseDTO> allKBsList = allKBs.knowledgebases();
		System.out.println("Name"+ "\t\t\t\t" + "Knowledge Base ID String");
		String KBIDList = " ";
		for(KnowledgebaseDTO KBData:allKBsList) {
			System.out.println(KBData.name() + "\t\t\t" + KBData.id());	
			KBIDList += KBData.id() + " ";
		}
		System.out.println();
		return KBIDList;
	}
	
	public Map<String,String> mapKnowledgebases(){
		KnowledgebasesDTO allKBs = kb_client.listAll();
		List<KnowledgebaseDTO> allKBsList = allKBs.knowledgebases();
		Map<String,String> map = new HashMap<String,String>();
		for(KnowledgebaseDTO KBData:allKBsList) {
			map.put(KBData.name(), KBData.id());	
		}
		return map;
	}
	
	//-------Residual methods-------------------------//
	
	public String query_kb(String kb_id, String question_) {
		System.out.println("Sending query to KB...");
		
		var runtime_key = keys_client.getKeys().primaryEndpointKey();
		QnAMakerRuntimeClient runtime_client = QnAMakerRuntimeManager.authenticate(runtime_key).withRuntimeEndpoint(runtime_endpoint);
		var query = (new QueryDTO()).withQuestion(question_);
		var result = runtime_client.runtimes().generateAnswer(kb_id, query);
		
		String aggregate = result.answers().get(0).answer().toString();
		double maxScore = result.answers().get(0).score();
		
		//send to voice module
		if(maxScore<31) {
			aggregate = "Error: The question you have asked is not in the database. Please try again.";
			//given an initial speech code, will encode where to send?
		}
		
		return aggregate;
	}
	
	public String wait_for_operation(Operation op) throws Exception {
	    System.out.println ("Waiting for operation to finish...");
	    Boolean waiting = true;
	    String result = "";
	    while (true == waiting) {
	        var op_ = ops_client.getDetails(op.operationId());
	        var state = op_.operationState();
	        if (OperationStateType.FAILED == state) {
	            throw new Exception("Operation failed.");
	        }
	        if (OperationStateType.SUCCEEDED == state) {
	            waiting = false;
	            // Remove "/knowledgebases/" from the resource location.
	            result = op_.resourceLocation().replace("/knowledgebases/", "");
	        }
	        if (true == waiting) {
	            System.out.println("Waiting 10 seconds for operation to complete...");
	            Thread.sleep(10000);
	        }
	    }
	    return result;
	}
}  


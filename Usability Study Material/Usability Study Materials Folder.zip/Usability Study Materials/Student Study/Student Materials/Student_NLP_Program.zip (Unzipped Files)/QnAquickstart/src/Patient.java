/*
 * BIOE Team Design
 * Year: 2020-2021
 * 
 * This class constructs a Patient profile with the relevant information needed 
 * to specify the patient's voice characteristics, appropriate knowledge base,
 * and basic information.
 * 
 *  The class is written under the assumption there is a way to easily query data
 *  from Biogears. Data required from Biogears have an in-line comment containing
 *  EDITME.
 * 
 * Clients are able to use the following list of methods to acquire data:
 * 
   - getProsodyRate()
   - getGCS()
   - getStrokeLocation()
   - getVoice()
   - getGlasgowComaScale()
   - getScenarioName()
   - getKbId()

 */

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class Patient {
	private String gender;
	private int age;
	private String scenarioName = "None";
	private String kb_id;
	private Map<String,String> kb;
	private String voice;
	private String prosodyRate = "0.9"; // speech speed
	public String voiceStyle = "chat";
	/*
	 * For new scenarios/diseases:
	 * ADD MORE instance variables that relate to affecting the voice characteristics.
	 * Default as a healthy patient status
	 */
	private int glasgowComaScale = 15; // 15 --> healthy patient 
	private String strokeLocation = "None";
	private MemoryFunctionConcept memory = null; //please don't touch, needed for a function file

	// Makes a patient constructor with information queried in Biogears	
	// CHANGE FOR USABILITY STUDY
	public Patient(KBMakerClient quickstart) {
		this.gender = "Male"; // EDITME getGender in Biogears | EDIT IN USABILITY STUDY
		this.age = 25; // EDITME getAge in Biogears | EDIT IN USABILITY STUDY
		
		// Determine voice based on gender
		if (gender.equals("Male")) {
			this.voice = "en-US-GuyNeural";
		} else {
			this.voice = "en-US-JennyNeural";
		}
		kb = quickstart.mapKnowledgebases();
	}

	// Returns a String of the prosody rate or speed of speech used for Microsoft Azure
	public String getProsodyRate() {
		return this.prosodyRate;
	}

	// Returns an int of the current GCS
	public int getGCS() {
		return this.glasgowComaScale;
	}

	// Returns a String of the current stroke location
	// If there is not a stroke, returns "None".
	public String getStrokeLocation() {
		return this.strokeLocation;
	}

	// Returns a String voice name used for Microsoft Azure.
	public String getVoice() {
		return this.voice;
	}

	// Returns a String of the current GCS severity.
	public int getGlasgowComaScale() {
		return this.glasgowComaScale;
	}

	// Returns a String of the current scenario name.
	public String getScenarioName() {
		return this.scenarioName;
	}

	// Returns a String of knowledge base ID used in Microsoft Azure.
	public String getKbId() {
		return this.kb_id;
	}

	// Returns a MemoryFunctionConcept to checks whether patient has been asked a memory question.
	public MemoryFunctionConcept getMemory() {
		return this.memory;
	}
	
	// Returns a MemoryFunctionConcept to checks whether patient has been asked a memory question.
	public int getAge() {
		return this.age;
	}

	// Returns a String of items the patient recalled based on GCS severity and given input.
	public String recallMemory() {
		return this.memory.recall();
	}

	// Returns a MemoryFunctionConcept based on the given input and the patient's GCS severity
	// and location of the stroke.
	public MemoryFunctionConcept makeMemory(String input) {
		this.memory = new MemoryFunctionConcept(input, this.glasgowComaScale,
				this.strokeLocation);
		return this.memory;
	} 

	// Updates scenario, knowledge base, and the corresponding speech-relevant variables.
	public void updatePatient() {
		String queryBiogearScenario = "Practice Healthy Patient"; // EDITME getScenario | EDIT IN USABILITY STUDY
		if (queryBiogearScenario.contains("Stroke Patient")) {
			strokeScenerioInfo(queryBiogearScenario);
		} else if (queryBiogearScenario.equals("Healthy Patient")) {
			healthyScenerioInfo(queryBiogearScenario);
		} else if (queryBiogearScenario.equals("Practice Healthy Patient")) {
			practiceHealthyScenerioInfo(queryBiogearScenario);
		} else {
			System.out.println("ERROR: Update not found.");
			// ADD new scenario update info. XXXScenrioInfo(queryBiogearScenario);
			// If applicable, add on instance variables that affect speech/kb choice
		}
	}

	// Returns a map of Strings of the corresponding knowledge base ids and its scenario name
	// Assumes a CSV file format of "Scenario, kb_id"
	private Map<String,String> getList() {
		return kb;
	}

	// Update stroke patient information relevant to speech and knowledge base
	private void strokeScenerioInfo(String queryBiogearScenario) {
		this.strokeLocation = "Right Parietal"; // EDITME getLocation in Biogears | EDIT IN USABILITY STUDY
		this.scenarioName = this.strokeLocation + " " + queryBiogearScenario;
		this.glasgowComaScale = 9; // EDITME get GCS in Biogears | EDIT IN USABILITY STUDY
		if (this.glasgowComaScale >= 7 && this.glasgowComaScale <= 13) {
			String[] speechSpeed = {"0.05", "0.1", "0.2", "0.3", "0.4", "0.5", "0.65"};
			this.prosodyRate = speechSpeed[this.glasgowComaScale - 7];
		} else if (this.glasgowComaScale <= 6){
			this.prosodyRate = "0.01";
		}
		this.kb_id = kb.get(this.scenarioName);
	}
	
	// Update a healthy patient information and its knowledge base
	private void healthyScenerioInfo(String queryBiogearScenario) {
		this.scenarioName = queryBiogearScenario;
		this.kb_id = kb.get(this.scenarioName);
	}
	
	// Update a healthy patient information and its knowledge base
	private void practiceHealthyScenerioInfo(String queryBiogearScenario) {
			this.scenarioName = queryBiogearScenario;
			this.kb_id = kb.get(this.scenarioName);
	}
	
	// Skeleton of an update function for another scenario with require variables
	/*
		private void XXXScenerioInfo(String queryBiogearScenario) {
			this.scenarioName = queryBiogearScenario;
			this.kb_id = kb.get(this.scenarioName);
			// ANY OTHER RELEVANT INFO
		}
	*/
}

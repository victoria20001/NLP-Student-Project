import java.io.IOException;

public class TrialsClass {
	public static void main(String[] args){
		System.out.println("Hello World");
	}
}

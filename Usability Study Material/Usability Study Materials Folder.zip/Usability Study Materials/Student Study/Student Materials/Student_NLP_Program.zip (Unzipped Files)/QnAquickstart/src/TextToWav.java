
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

import com.microsoft.cognitiveservices.speech.AudioDataStream;
import com.microsoft.cognitiveservices.speech.SpeechConfig;
import com.microsoft.cognitiveservices.speech.SpeechSynthesizer;
import com.microsoft.cognitiveservices.speech.SpeechSynthesisOutputFormat;
import com.microsoft.cognitiveservices.speech.SpeechSynthesisResult;
import com.microsoft.cognitiveservices.speech.audio.AudioConfig;

//This file is used to speak text to a wave file. Useful in conjunction with QnAFunctionDeveloper
//You will have to modify 1) what you want spoken in line 23 and 2) the output file path in line 30.
public class TextToWav {
	public static void main(String[] args) {
		SpeechConfig speechConfig = SpeechConfig.fromSubscription("05e36504b6e6481c86d587965e59af57", "eastus");
		SpeechSynthesizer synthesizer = new SpeechSynthesizer(speechConfig, null);
		
		// additional speech modifiers can be found at: 
		// https://docs.microsoft.com/en-us/azure/cognitive-services/speech-service/speech-synthesis-markup?tabs=csharp
	    String textToSpeak = "<speak version=\"1.0\" xmlns=\"https://www.w3.org/2001/10/synthesis\" xml:lang=\"en-US\">"
				+ " <voice name=\"en-US-BenjaminRUS\">"
				+ " <prosody rate=\".9\">"
				+ " " + "What is 21 subtracted by 7?" 
				+ " </prosody>"
				+ "  </voice>"
				+ "</speak>";
	    SpeechSynthesisResult result = synthesizer.SpeakSsml(textToSpeak);
	    System.out.println(textToSpeak);
	    AudioDataStream stream = AudioDataStream.fromResult(result);
	    stream.saveToWavFile("/Users/trevorjohnston/Desktop/AMMAudioFiles/trialCalculate5.wav");
	}
}

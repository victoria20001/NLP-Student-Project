/*
 * BIOE Team Design
 * Year: 2020-2021
 * 
 * This class constructs a memory for an existing patient to be able to remember a
 * list of items and recite them.
 * 
 * The class is written under the assumption there the patient has information
 * on GCS and location of stroke in brain. Note the locations evaluated so far
 * are parietal lobe, occipital lobe, and cerebellum.
 * 
 * Clients are able to use the following list of methods to acquire data:
 * 
   - MemoryFunctionConcept(String input, int _severity, String _location)
   - getTriggerWords()
   - recall()

 */

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import com.github.dhiraj072.randomwordgenerator.RandomWordGenerator; // DELETE if errors arise

public class MemoryFunctionConcept {
	//static variables
	private static List<String> triggerWords = new ArrayList<String>(Arrays.asList("repeat", "remember",
																				   "after me"));
	private static List<String> randomWords = new ArrayList<String>(Arrays.asList("Bacon", "Blue" ,
																				  "Whale", "Couch",
																				  "Beluga", ""));
	//instance variables
	private List<String> relevantStrokeLocations = new ArrayList<String>(Arrays.asList("Left Parietal",
																					   "Cerebellum",
																					   "Right Parietal"));
	private String rememberedItems;	// the 3 words the method will be remembering
	private int severity; 			// GCS (Glasgow Coma Scale)
	private String location;		// to be implemented
	private int recalledTimes = 0; 	// how many times this instance has been called
	//Note: probably want to have this tested using %2 in case patient is asked again.
	Random rand;
	
	// Constructor taking String input and int of GCS severity, and location; 
	// sets rememberedItems from input and stores severity. 
	public MemoryFunctionConcept(String input, int _severity, String _location) {
		
		int start = 0;
		if (input.contains("repeat after me") || input.contains("after me")) {
			start = input.indexOf("after me") + "after me ".length();
		}
		else if (input.contains("following words")) {
			start = input.indexOf("following words")+ "following words ".length();
		}
		else if (input.contains("please remember") || input.contains("Please remember")) {
			start = input.indexOf("lease remember")+ "lease remember ".length();
		}	
		
		// Takes account of case when speech to text splits statement to separate 
		// sentences
		if (input.contains(".")) {
			if (input.substring(start, input.indexOf(".", start)).length() == 0) {
				String columns[] = input.split(".");
				rememberedItems = columns[1];	
			} else {
				rememberedItems = input.substring(start, input.indexOf(".", start));
			}
		} else {
			if (input.substring(start, input.indexOf("?", start)).length() == 0) {
				String columns[] = input.split("?");
				rememberedItems = columns[1];	
			} else {
				rememberedItems = input.substring(start, input.indexOf("?", start));
			}
		}
		
		severity = _severity;
		location = _location;
		rand = new Random();
	}
	
	// Returns a list of the trigger words for this class/function
	public static List<String> getTriggerWords() {
		return triggerWords;
	}
	
	public int getRecalledTimes() {
		return recalledTimes;
	}
	
	// Returns the stored words with severity-appropriate and timesRecalled-appropriate modifications.
	public String recall() {
		boolean affectShortMemoryStroke = false;
		for (int i = 0; i < relevantStrokeLocations.size() && !affectShortMemoryStroke; i++) {
			if (location.equals(relevantStrokeLocations.get(i))) {
				affectShortMemoryStroke = true;
			}
		}
		boolean affectShortMemoryGCS = false;
		if(severity<14) {
			affectShortMemoryGCS = true;
		}
		
		if (affectShortMemoryGCS || affectShortMemoryStroke) {
			if ((severity == 14 || severity == 15) && !affectShortMemoryStroke) {
				recalledTimes ++;
				return rememberedItems;
			}
			else if((severity == 12 || severity == 13) && !affectShortMemoryStroke) {
				recalledTimes ++;
				if (recalledTimes <= 1) {
					return rememberedItems;
				}
				else {
					int firstSpace = rememberedItems.indexOf(" ");
					int secondSpace = rememberedItems.indexOf(" ", firstSpace);
					return rememberedItems + " and I can't remember the last one";
				}
			}
			else if(severity == 11 || severity == 10 || affectShortMemoryStroke) {
				recalledTimes ++;
				if (recalledTimes<=1) {
					int firstSpace = rememberedItems.indexOf(" ");
					int secondSpace = rememberedItems.indexOf(" ", firstSpace+1);
					return rememberedItems.substring(0, secondSpace) + " and I can't remember the last one";
				}
				else {
					return RandomWordGenerator.getRandomWord() + "? I can't seem to remember";
					// return "... " + randomWords.get(rand.nextInt(randomWords.size())) + "? I can't seem to remember";
				}
			}
			else if (severity == 9) {
				return RandomWordGenerator.getRandomWord() + "? I can't seem to remember";
				// return "... " + randomWords.get(rand.nextInt(randomWords.size())) + "? I can't seem to remember";
			}
			else {
				return "...huhh...urgh...uh"; // Incomprehensible sounds
			}
			
		} else {
			recalledTimes ++;
			return rememberedItems;
		}	
	}
	
	// 
	public void updateSeverity(int newSeverity) {
		severity = newSeverity;
	}
	
	public void updateLocation(String newLocation) {
		location = newLocation;
	}
	
	// add new random words
	
}


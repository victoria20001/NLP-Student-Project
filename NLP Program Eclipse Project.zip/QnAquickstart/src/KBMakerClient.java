// <dependencies>
/* Download the following files.
 * - https://repo1.maven.org/maven2/com/microsoft/azure/cognitiveservices/azure-cognitiveservices-qnamaker/1.0.0-beta.1/azure-cognitiveservices-qnamaker-1.0.0-beta.1.jar
 * - https://repo1.maven.org/maven2/com/microsoft/azure/cognitiveservices/azure-cognitiveservices-qnamaker/1.0.0-beta.1/azure-cognitiveservices-qnamaker-1.0.0-beta.1.pom
 * Move the downloaded .jar file to a folder named "lib" directly under the current folder.
 * Rename the downloaded file to pom.xml.
 * At the command line, run
 * mvn dependency:copy-dependencies
 * This will download the .jar files depended on by azure-cognitiveservices-qnamaker-1.0.0-beta.1.jar to the folder "target/dependency" under the current folder. Move these .jar files to the "lib" folder as well.
 */
import com.microsoft.azure.cognitiveservices.knowledge.qnamaker.*;
//These are to resolve typing
import com.microsoft.azure.cognitiveservices.knowledge.qnamaker.models.*;
import com.microsoft.azure.cognitiveservices.knowledge.qnamaker.models.QnADTO;
import com.microsoft.azure.cognitiveservices.knowledge.qnamaker.models.CreateKbDTO;
import com.microsoft.azure.cognitiveservices.knowledge.qnamaker.QnAMakerClient;

import java.io.*;
import java.lang.Object.*;
import java.time.format.DateTimeFormatter;  
import java.time.LocalDateTime; 
import java.util.*;
import java.net.*;

// </dependencies>


/* This sample contains methods to do the following tasks in this method or in others.
 * Create a knowledge base.
 * Update a knowledge base.
 * Publish a knowledge base.
 * Download a knowledge base.
 * Query a knowledge base.
 * Delete a knowledge base.
 * HOWEVER, if you actually want to make a KB, run this code (the main method is at the end).
*/


/* BIOLERPLATE COMMENTS FROM ONLINE SAMPLE:
 * To compile and run, enter the following at a command prompt:
 * javac Quickstart.java -cp .;lib\*
 * java -cp .;lib\* Quickstart
 * This presumes your libraries are stored in a folder named "lib"
 * directly under the current folder. If not, please adjust the
 * -classpath/-cp value accordingly.
 */

public class KBMakerClient {
	// <resourceKeys>
	/* Configure the local environment:
	* Set the following environment variables on your local machine using the
	* appropriate method for your preferred shell (Bash, PowerShell, Command
	* Prompt, etc.).
	*
	* QNA_MAKER_SUBSCRIPTION_KEY
	* QNA_MAKER_ENDPOINT
	* QNA_MAKER_RUNTIME_ENDPOINT
	*
	* If the environment variable is created after the application is launched in a console or with Visual
	* Studio, the shell (or Visual Studio) needs to be closed and reloaded to take the environment variable into account.
	*/
		
		/*
		// Trevor's: Currently on Free Tier
		public static String authoring_key = "1b3c5e46341e4952a59a51dfac9ea5bc";
		public static String authoring_endpoint = "https://qandamaker1.cognitiveservices.azure.com";
		public static String runtime_endpoint = "https://qandamaker1.azurewebsites.net";
		*/
	
		
		// Trevor's #2: Currently on Basic Tier (as created)
		public static String authoring_key = "6d7e89dd1ee74e2a8c067ecd3d0f928a";
		public static String authoring_endpoint = "https://qandamaker2.cognitiveservices.azure.com";
		public static String runtime_endpoint = "https://qandamaker2.azurewebsites.net";
		
		
		/*
		// Laila's: Currently on Free Tier
		public static String authoring_key = "bbc0b0cbef5347c1a759e0d691a458bc";
		public static String authoring_endpoint = "https://qandamakernew.cognitiveservices.azure.com";
		public static String runtime_endpoint = "https://qandamakernew.azurewebsites.net";
		*/
		
		/*
		// Hienschi's: Currently on Free Tier
		public static String authoring_key = "b2bd05208bb4498a9837fe88733585fd";
		public static String authoring_endpoint = "https://uwcrest.cognitiveservices.azure.com";
		public static String runtime_endpoint = "https://uwcrest.azurewebsites.net";
		*/ 
		
	private static String question;
	// </resourceKeys>

	// <authenticate>
	/* Note QnAMakerManager.authenticate() does not set the baseUrl paramater value
	 * as the value for QnAMakerClient.endpoint, so we still need to call withEndpoint().
	 */
	QnAMakerClient authoring_client = QnAMakerManager.authenticate(authoring_key).withEndpoint(authoring_endpoint);
	Knowledgebases kb_client = authoring_client.knowledgebases();
	Operations ops_client = authoring_client.operations();
	EndpointKeys keys_client = authoring_client.endpointKeys();
	// </authenticate>
	
	// alternate constructor
	public KBMakerClient(String _authoring_key, String _authoring_endpoint, String _runtime_endpoint) {
		authoring_key = _authoring_key;
		authoring_endpoint = _authoring_endpoint;
		runtime_endpoint = _runtime_endpoint;
		authoring_client = QnAMakerManager.authenticate(authoring_key).withEndpoint(authoring_endpoint);
		kb_client = authoring_client.knowledgebases();
		ops_client = authoring_client.operations();
		keys_client = authoring_client.endpointKeys();
	}
	
	public KBMakerClient() {
	}
	
	
	
	public void updateQuestion(String _question) {
		question = _question;
	}
	
	public Map<String,String> mapKnowledgebases(){
		KnowledgebasesDTO allKBs = kb_client.listAll();
		List<KnowledgebaseDTO> allKBsList = allKBs.knowledgebases();
		Map<String,String> map = new HashMap<String,String>();
		for(KnowledgebaseDTO KBData:allKBsList) {
			map.put(KBData.name(), KBData.id());	
		}
		return map;
	}
	
	// <listKbs>
	public void list_kbs() {
		System.out.println("Listing KBs...");
		var result = kb_client.listAllAsync();
		result.subscribe(kbs -> {
			for (var kb : kbs.knowledgebases()) {
				System.out.println(kb.id().toString()); //changed to println
			};
		});
		System.out.println();
	}
	// </listKbs>

	// <waitForOperation>
	public String wait_for_operation(Operation op) throws Exception {
		System.out.println ("Waiting for operation to finish...");
		Boolean waiting = true;
		String result = "";
		while (true == waiting) {
			var op_ = ops_client.getDetails(op.operationId());
			var state = op_.operationState();
			if (OperationStateType.FAILED == state) {
				throw new Exception("Operation failed.");
			}
			if (OperationStateType.SUCCEEDED == state) {
				waiting = false;
				// Remove "/knowledgebases/" from the resource location.
				result = op_.resourceLocation().replace("/knowledgebases/", "");
			}
			if (true == waiting) {
				System.out.println("Waiting 10 seconds for operation to complete...");
				Thread.sleep(10000);
			}
		}
		return result;
	}
	// </waitForOperation>

	// <createKb>
	public String create_kb () throws Exception {
		System.out.println("Creating KB...");

		String name = "Stroke Parietal";

		var metadata = new MetadataDTO()
			.withName ("Category")
			.withValue ("api");

		List<MetadataDTO> metadata_list = Arrays.asList(new MetadataDTO[]{ metadata });

		var qna = new QnADTO()
			.withAnswer ("Speaker 2:The lesion is located at the parietal lobe.")
			.withQuestions ( Arrays.asList(new String[]{ "Where is the stroke lesion?" }))
			.withMetadata (metadata_list);
		
		var qna2 = new QnADTO()
				.withAnswer ("Speaker 1:Maybe?")
				.withQuestions ( Arrays.asList(new String[]{ "Can you see this?" }))
				.withMetadata (metadata_list);

		List<QnADTO> qna_list = Arrays.asList(new QnADTO[]{ qna , qna2});


		var payload = new CreateKbDTO().withName(name).withQnaList(qna_list);

		var result = kb_client.create(payload);
		var kb_id = wait_for_operation(result);

		System.out.println("Created KB with ID: " + kb_id + ".\n");
		return kb_id;
	}
	// </createKb>

	// <updateKb>
	public void update_kb (String kb_id) throws Exception {
		System.out.println("Updating KB...");

		var update = new UpdateKbOperationDTOUpdate().withName ("New KB name");

		var payload = new UpdateKbOperationDTO().withUpdate((UpdateKbOperationDTOUpdate)update);

		var result = kb_client.update(kb_id, payload);
		wait_for_operation(result);

		System.out.println("Updated KB.");
	}
	// </updateKb>

	// <publishKb>
	public void publish_kb(String kb_id) {
		System.out.println("Publishing KB...");
		kb_client.publish(kb_id);
		System.out.println("KB_ID: " + kb_id + " published.\n");
	}
	// </publishKb>

	// <downloadKb>
	public void download_kb(String kb_id) {
		System.out.println("Downloading KB...");

		var kb_data = kb_client.download(kb_id, EnvironmentType.PROD);
		System.out.println("KB Downloaded. It has " + kb_data.qnaDocuments().size() + " question/answer sets.");

		System.out.println("Downloaded KB.\n");
	}
	// </downloadKb>

	// <queryKb>
	public String query_kb(String kb_id, String question_) {
		System.out.println("Sending query to KB...");
		
		var runtime_key = keys_client.getKeys().primaryEndpointKey();
		QnAMakerRuntimeClient runtime_client = QnAMakerRuntimeManager.authenticate(runtime_key).withRuntimeEndpoint(runtime_endpoint);
		var query = (new QueryDTO()).withQuestion(question_);
		var result = runtime_client.runtimes().generateAnswer(kb_id, query);
		String aggregate = result.answers().get(0).answer().toString();
		double maxScore = result.answers().get(0).score();
		
		//send to voice module
		if(maxScore<31) {
			aggregate = "Speaker 2: Error. The question you have asked is not in the database. Please try again.";
			//given an initial speech code, will encode where to send?
		}
		//System.out.println(aggregate);
		return aggregate;
	}
	// </queryKb>

	// <deleteKb>
	public void delete_kb(String kb_id) {
		System.out.println("Deleting KB...");
		kb_client.delete(kb_id);
		System.out.println("KB deleted.\n");
	}
	// </deleteKb>

	// <main>
    public static void main(String[] args) {
		try {
			
			KBMakerClient quickstart = new KBMakerClient();
			
			
			String kb_id = "acb40a3c-e691-43e4-a8ec-4da7da2f10c1";
	
			
			//quickstart.delete_kb(kb_id1);
	
			//String kb_id = quickstart.create_kb();
			
			//quickstart.publish_kb(kb_id);
			
			//String answer = quickstart.query_kb(kb_id,"Where is the lesion?");
			
			
			//System.out.println(answer);
			
			System.out.print(kb_id);
			String answer = quickstart.query_kb(kb_id,"Can you write your name?");
			System.out.println(answer);
			
			
			
			//String kb_id = "4ab06d10-7587-4ef8-9112-82b50100c292";
			//quickstart.delete_kb(kb_id);
			
			/*
			System.out.println(quickstart.authoring_key);
			System.out.println(quickstart.authoring_endpoint);
			System.out.println(quickstart.runtime_endpoint);
			quickstart.query_kb(kb_id,"Can you see this?");
			*/
			//String outputFilePath =  "/Users/trevorjohnston/Desktop/AMMAudioFiles/Test5.xlsx";
			
			//boolean folderPathExists = new File(outputFilePath.substring(0,outputFilePath.lastIndexOf("/"))).exists();
			
			//System.out.println(folderPathExists);

			
        } catch (Exception e) {
            System.out.println(e.getMessage());
            e.printStackTrace();
        }
    }
	// </main>
}


/*
 * BIOE Team Design
 * Year: 2020-2021
 * 
 * This class contain a function that conducts mathematical calculations and adjust
 * answers to GCS severity/stroke lesion location accordingly.
 * 
 * The class is written under the assumption there the patient has information
 * on GCS and location of stroke in brain. Note the locations evaluated so far
 * are parietal lobe, occipital lobe, and cerebellum.
 * 
 * Clients are able to use the following list of methods to acquire data:
 * 
   - makeCalculation(String input, int severity, String location)
   - getTriggerWords()

 */

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;


import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

public class CalculateFunctionConcepts {
	private static List<String> relevantStrokeLocations = new ArrayList<String>(Arrays.asList("Right Parietal",
																							  "Right Parietal Lobe",
																							  "Right Parietal Stroke"));
	public static final String GOOGLE_SEARCH_URL = "https://www.google.com/search";
	private static List<String> triggerWords = new ArrayList<String>(Arrays.asList("calculate",
																					"multiplied by" , "divided by",
																					"square root", "times by",
																					"minus", "-","--", "*","/","+",
																					"sqrt","subtracted by","added to","plus"));
	private static String searchTrigger = "<div class=\"BNeawe iBp4i AP7Wnd\">\n"
			+ "             <div>\n"
			+ "              <div class=\"BNeawe iBp4i AP7Wnd\">\n"
			+ "               ";
	
	// Takes String input calculation command and based GCS severity and location (to be implemented), will
	// returns a String of the adjusted answer to the requested calculation
	public static String makeCalculation(String input, int severity, String location) throws IOException{
		input = input.replace("--","-");
		input = input.replace("+","plus");
		boolean affectCalculateGCS = false;
		boolean affectCalculateStroke = false;
		
		if(severity<14) {
			affectCalculateGCS = true;
		}
		
		for (int i = 0; i < relevantStrokeLocations.size() && !affectCalculateStroke; i++) {
			if (location.equals(relevantStrokeLocations.get(i))) {
				affectCalculateStroke = true;
			}
		}
		
		if (affectCalculateGCS || affectCalculateStroke) {
			if(affectCalculateStroke) {
				Random rand = new Random();
				if(rand.nextDouble() > .5) {
					return "Speaker 1: ...I don't know";
				}
				else {
					return "Speaker 1: I think it is " + rand.nextInt(100);
				}
			}
			else if(severity >= 11 && severity <= 13) {
				String correctAnswer = googleSearch(input);
				double answer = (double)Double.parseDouble(correctAnswer);
				double maxDeviation = answer * .2;
				double minAnswer = answer-maxDeviation;
				int actualDeviation = (int) Math.round((Math.random() * maxDeviation * 2));
				double actualAnswer= actualDeviation+minAnswer;
				if (actualAnswer % 1 == 0) {
					return "Speaker 1: " + (int)actualAnswer;
				}
				return "Speaker 1: " + actualAnswer;
			} 
			else if (severity == 10 || severity == 9) {
				Random rand = new Random();
				if(rand.nextDouble() > .5) {
					return "Speaker 1: ...I don't know";
				}
				else {
					return "Speaker 1: I think it is " + rand.nextInt(100);
				}
			} 
			else {
				return "Speaker 1: ...huhh...urgh...uh"; // Incomprehensible sounds
			}
		} else {
			return "Speaker 1: " + googleSearch(input);
		}		
	}
	
	// Returns a list of the trigger words for this class/function (make sure it is static!)
	public static List<String> getTriggerWords(){
		return triggerWords;
	}
	
	// Returns a String of the requested math calculation
	public static String googleSearch(String input) throws IOException {
		String searchURL = GOOGLE_SEARCH_URL + "?q="+input;
		Document doc = Jsoup.connect(searchURL).userAgent("Mozilla/5.0").get();
		String docString = doc.html();
		int firstIndex = docString.indexOf(searchTrigger);
		String calcResult = docString.substring(firstIndex+searchTrigger.length(),
												firstIndex+searchTrigger.length()+7).replaceAll("\\s", "");
		return calcResult;
	}
}

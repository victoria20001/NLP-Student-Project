// Favour Orji
// CREST AMM
// Stuttering 

/*
   This program will attempt to replicate stuttering that is seen in TBI related injuries
   Notes: 
      - Stuttering code modified based on GGlasgow Stroke Scale:
         - Broca's Aphasia:Injury to the frontal regions of the left hemisphere impacts 
           how words are strung together to form complete sentences. 
           This can lead to Broca’s Aphasia, which is characterized by:
              - Difficulty forming complete sentences.
              - Leaving out words like “is” or “the.”
              - Saying something that doesn’t resemble a sentence.
              - Trouble understanding sentences.  
         - Wernicke's Aphasia: 
         - Global Aphasia: A stroke that affects an extensive portion of your 
           front and back regions of the left hemisphere may result in Global Aphasia. 
           You may have difficulty:
              - Understanding words and sentences.
              - Forming words and sentences.

          Overall scale:
            - Oriented, confused, inappropirate words, incomprehendible, and no response

Note the locations evaluated so far
 * are parietal lobe, occipital lobe, and cerebellum.

 */
import java.util.*;

public class SlurredStutters {
	private static List<String> relevantStrokeLocations = new ArrayList<String>(Arrays.asList("Cerebellum"));

	public static void main(String[] args) {
		String test = "This is the way of the world.";
		System.out.println(qnAStutters(test, 8));
	}
	
	public static String slurredResponse(String response, int GCSseverity, String strokeLocation){
		boolean affectResponseStroke = false;
		
		for (int i = 0; i < relevantStrokeLocations.size() && !affectResponseStroke; i++) {
			if (strokeLocation.equals(relevantStrokeLocations.get(i))) {
				affectResponseStroke = true;
			}
		}

		if (affectResponseStroke) {
			return qnAStutters(response, 4) + response;
		} else if (GCSseverity <=13){
			if (GCSseverity <= 13 && GCSseverity>=7) {
				return qnAStutters(response, GCSseverity);
			} else {
				return "Speaker 2: Patient was unable to verbally respond.";
			}
		}	
		return response;
	}

	
	// non-vowels randomly replaced with r
	// s --> sh
	// the --> duh
	// for --> foh
	// up --> op
	// randomly insert uh between words check
	
	// also, just filer audio output
	public static String qnAStutters(String qnAResponse, int GCSScore){
		String newResponse = qnAResponse.replaceAll("the ", "duh ");
		newResponse = newResponse.replaceAll("for", "fuh");
		newResponse = newResponse.replaceAll("is ", "iz ");
		String[] consonantList = {"b","c","d","f","g","h","j","k","l", "m", "n", "p", "t", "v", "w", "z"};
		int multiplicity = 0;
		if(GCSScore == 13 || GCSScore == 12) {
			multiplicity = 3;
		}
		else if(GCSScore == 11 || GCSScore == 10) {
			multiplicity = 4;
		}
		else if(GCSScore <= 10) {
			multiplicity = 5;
		}
		
	     for(int i = 0; i < newResponse.length(); i++) {
	    	 if(newResponse.indexOf("duh ",i) == i || newResponse.indexOf("fuh ",i) == i) {
	    		 i = i+3;
	    	 }
	    	 else if(newResponse.indexOf("iz ",i) == i) {
	    		 i = i+2;
	    	 }
	    	 else if(newResponse.substring(i,i+1).equals(" ") && Math.random()*multiplicity > 3) {
	    			 newResponse = newResponse.substring(0,i+1) + "...uh... " + newResponse.substring(i+1,newResponse.length());
	    			 i = i + 8;
	    	 }
	    	 else {
	    		 String currLetter = newResponse.substring(i,i+1);
	    		 for(int j = 0; j<consonantList.length; j++) {
	    			 if(currLetter.equals(consonantList[j])) {
	    				 if(Math.random()*10>8) {
	    					 newResponse = newResponse.substring(0,i) + "r" + newResponse.substring(i+1,newResponse.length());
	    				 }
	    			 }
	    	 	}
    			if(currLetter.equals("s")) {
    				 newResponse = newResponse.substring(0,i) + "sh" + newResponse.substring(i+1,newResponse.length());
    				 i=i+1;
    			}
	    	 }
	     }
	     return newResponse;
	}
	
	
	
	// okay, lets rethink
	// Every a is drawn out.
	private static String slurredL1(String qnAResponse){
		String L1 = qnAResponse;
		String replaceL1 = L1.replace("a", "aaaaa");
		return replaceL1;
	}  

	// Every third word is said three times.
	private static String slurredL2(String qnAResponse){
		String line = "";
		String[] arr = qnAResponse.split("\\s+");
		for (int i = 0; i < arr.length; i++){
			line += arr[i] + " ";

			if ((i+1) % 3 == 0) {
				line += arr[i] + " ";

				line += arr[i] + " ";
			}
		}
		return line;
	}

	// all "is" and "the" are removed
	private static String slurredL3(String qnAResponse){
		String L2 =  qnAResponse;
		String replaceL2 = L2.replaceAll("is", "").replaceAll("the", "");

		return replaceL2;
	}

	// Makes words start with "uh" repetatively.
	private static String slurredL4(String response) {
		Scanner sc = new Scanner(response);
		int skip = (int)(Math.random()*8+1);
		int count = 0;
		int repeat = (int)(Math.random()*2+1);
		String s = ""; 
		while(sc.hasNext()){
			String word = sc.next();
			if (count % skip == 0){
				for (int i = 0; i < repeat; i++){
					s += word.charAt(0) + "uh";
				} 
				skip = (int)(Math.random()*4+1);
				repeat = (int)(Math.random()*2+1);
			} 
			s += word + " ";
			count++;
		}
		return s;
	}

	// just skips words
	private static String slurredL5(String response){
		Scanner sc = new Scanner(response);
		int skip = 2;
		int count = -1;
		String s = ""; 
		while(sc.hasNext()) {
			String word = sc.next();
			if (count % skip != 0){
				s += word + " ";
			} 
			count++;
		}
		return s;
	}

	// just skips words more frequently
	private static String slurredL6(String response) {
		Scanner sc = new Scanner(response);
		int skip = 3;
		int count = -1;
		String s = ""; 
		while(sc.hasNext()){
			String word = sc.next();
			if (count % skip != 0){
				s += word + " ";
			} 
			count++;
		}
		return s;
	}
}

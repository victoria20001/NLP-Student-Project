import java.io.IOException;
import java.util.Scanner;
import java.util.Set;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

//<div class="BNeawe iBp4i AP7Wnd">

public class GoogleSearchJava {

	public static final String GOOGLE_SEARCH_URL = "https://www.google.com/search";
	public static void main(String[] args) throws IOException {
		//Taking search term input from console
		/*
		Scanner scanner = new Scanner(System.in);
		System.out.println("Please enter the search term.");
		String searchTerm = scanner.nextLine();
		scanner.close();
		*/
		
		//String searchURL = GOOGLE_SEARCH_URL + "?q="+searchTerm;
		String searchURL = GOOGLE_SEARCH_URL + "?q="+"What is 21 + 6";
		//without proper User-Agent, we will get 403 error
		Document doc = Jsoup.connect(searchURL).userAgent("Mozilla/5.0").get();
		
		//below will print HTML data, save it to a file and open in browser to compare
		String docString = doc.html();
		
		System.out.println(docString);
		
		String searchTrigger = "<div class=\"BNeawe iBp4i AP7Wnd\">\n"
				+ "             <div>\n"
				+ "              <div class=\"BNeawe iBp4i AP7Wnd\">\n"
				+ "               ";
		
		int firstIndex = docString.indexOf(searchTrigger);
		
		System.out.println(); System.out.println();
		System.out.println(firstIndex);
		
		String calcResult = docString.substring(firstIndex+searchTrigger.length(),firstIndex+searchTrigger.length()+7).replaceAll("\\s", "");
		System.out.println();
		System.out.println(calcResult);
		
	}

}

